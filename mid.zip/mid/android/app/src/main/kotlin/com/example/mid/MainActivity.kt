package com.example.mid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
